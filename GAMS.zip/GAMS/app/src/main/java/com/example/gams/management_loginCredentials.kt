package com.example.gams

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class management_loginCredentials : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_management_login_credentials)
    }
}